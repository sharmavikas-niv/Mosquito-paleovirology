setwd("D:/NIV_PUNE/supplemenatry_gene_syntany")

# Read input files
df <- read.delim("Trichoplusia_ni_TED_virus_orfB-5KB.fasta-rpsblast-seg_mapped.tsv",
                 sep = "\t", header = FALSE, stringsAsFactors = FALSE)

colnames(df) <- c(
  "query", "subject", "perc_identity", "align_len", "mismatches",
  "gap_opens", "q_start", "q_end", "s_start", "s_end",
  "evalue", "bit_score", "cdd_id", "cdd_idb_id", "gene", "function", "aa_len"
)
colnames(df)
head(df)

#grep pfam
library(dplyr)

df_filtered <- df %>%
  filter(grepl("pfam", cdd_idb_id, ignore.case = TRUE))

View(df_filtered)
nrow(df_filtered)


#save
write.csv(
  df_filtered,
  "pfam_rows_TED.csv",
  row.names = FALSE
)

#############################################################################
#ORF C with any domian of ORF B

library(dplyr)
library(ggplot2)
library(gggenes)


# 1. Define PFAM colors (your custom palette)
pfam_colors <- c(
  "pfam00078" = "#30123B",   # dark purple / almost black
  "pfam00665" = "#28BBEC",   # bright cyan
  "pfam03732" = "#A2FC3C",   # neon lime
  "pfam17917" = "#FB8022",   # orange
  "pfam17921" = "#7A0403",   # maroon
  "pfam12259" = "#8B008B"    # wine/purple
)

# PFAMs need to keep
pfam_keep <- c("pfam00078", "pfam00665", "pfam03732",
               "pfam17917", "pfam17921", "pfam12259")


# 2. Filter from df_filtered (the full dataset)
#    Keep only your PFAMs (no accessory domains)

df_filtered_keep <- df_filtered %>%
  filter(tolower(cdd_idb_id) %in% tolower(pfam_keep))


# 3. Find loci containing pfam12259

loci_with_12259 <- df_filtered_keep %>%
  filter(tolower(cdd_idb_id) == "pfam12259") %>%
  pull(query) %>%
  unique()


# 4. Filter to ONLY those loci (any PFAM combination of ORF C and ORF B)

df_plot_12259 <- df_filtered_keep %>%
  filter(query %in% loci_with_12259) %>%
  mutate(
    molecule = query,
    pfam     = cdd_idb_id,
    forward  = q_start <= q_end,
    xmin     = pmin(q_start, q_end),
    xmax     = pmax(q_start, q_end)
  )


# 5. Plot function
plot_multi_genome <- function(df) {
  ggplot(df, aes(
    xmin = xmin,
    xmax = xmax,
    y    = molecule,
    fill = pfam,
    forward = forward
  )) +
    geom_gene_arrow(
      arrowhead_height = unit(3, "mm"),
      arrowhead_width  = unit(1, "mm")
    ) +
    scale_fill_manual(
      name   = "PFAM ID",
      values = pfam_colors
    ) +
    scale_y_discrete(labels = function(x)
      gsub("genomic\\.fna_", "", x)) +
    theme_genes() +
    theme(
      axis.text.y  = element_text(size = 8,  color = "black"),
      axis.text.x  = element_text(size = 10, color = "black"),
      axis.title.x = element_text(color = "black"),
      axis.title.y = element_text(color = "black"),
      plot.title   = element_text(hjust = 0.5, face = "bold", size = 14),
      legend.position = "right",
      panel.grid      = element_blank()
    ) +
    labs(
      title = "",
      x = "Genomic coordinates (bp)",
      y = "Genomic locus"
    )
}


# 6. Plot ALL loci containing pfam12259 (ORF C) and ORF B

plot_multi_genome(df_plot_12259)


# 7. Plot ONLY the single locus prefix you want

locus_prefix <- "GCF_002204515.2_AaegL5.0_genomic.fna_"

plot_multi_genome(
  df_plot_12259 %>%
    filter(grepl(paste0("^", locus_prefix), molecule))
)


#8.Count how many loci for the chosen genomic prefix

locus_prefix <- "GCF_002204515.2_AaegL5.0_genomic.fna_"

count_loci_prefix <- df_plot_12259 %>%
  filter(grepl(paste0("^", locus_prefix), molecule)) %>%
  pull(molecule) %>%
  unique() %>%
  length()

cat("Number of loci for prefix:", locus_prefix, "=", count_loci_prefix, "\n")


####################################################################################
#locus count for all loci_prefix (ORF C with ORF B any domain)
library(dplyr)
library(stringr)

#1. Keep the reusable function
count_loci_for_prefix <- function(df, prefix) {
  df %>%
    filter(grepl(paste0("^", prefix), molecule)) %>%
    pull(molecule) %>%
    unique() %>%
    length()
}


#Add a small loop to cat() counts for ALL prefixes
prefixes <- c(
  "GCA_015732765.1_VPISU_Cqui_1.0_pri_paternal_genomic.fna_",
  "GCA_016801865.2_TS_CPP_V2_genomic.fna_",
  "GCA_024139115.2_GZ_Asu_2_genomic.fna_",
  "GCA_024533555.2_Akor_1.1_genomic.fna_",
  "GCA_029784155.1_ASM2978415v1_genomic.fna_",
  "GCA_029784165.1_ASM2978416v1_genomic.fna_",
  "GCA_030247185.2_Malgen_1.1_genomic.fna_",
  "GCA_030247195.1_ASM3024719v1_genomic.fna_",
  "GCA_034211315.2_Ajap1v2_genomic.fna_",
  "GCA_035046485.1_AalbF5_genomic.fna_",
  "GCA_037179485.2_CSIRO-AGI_Acam_v1.1_genomic.fna_",
  "GCA_040801935.1_CSIRO_AGI_Anoto_v1_genomic.fna_",
  "GCA_044231785.1_Aedes_sierrensis_1_genomic.fna_",
  "GCA_943734655.2_idSabCyanKW18_F2_genomic.fna_",
  "GCA_964187845.1_idCulLati1.1_genomic.fna_",
  "GCA_964213205.1_idCulMode1.1_genomic.fna_",
  "GCA_964243045.1_idCulPerx1.1_genomic.fna_",
  "GCA_964340515.1_idCulThei1.1_genomic.fna_",
  "GCF_002204515.2_AaegL5.0_genomic.fna_"
)
for (p in prefixes) {
  count <- count_loci_for_prefix(df_plot_12259, p)
  cat("Number of loci for prefix:", p, "=", count, "\n")
}

#################################################################################
####################################################################################


