setwd("D:/NIV_PUNE/supplemenatry_gene_syntany")


# Read input files
df <- read.delim("Cladosporium_fulvum.RT-5kb.fasta-rpsblast-seg_mapped.tsv", sep = "\t", header=FALSE, stringsAsFactors=FALSE)

colnames(df) <- c(
  "query", "subject", "perc_identity", "align_len", "mismatches",
  "gap_opens", "q_start", "q_end", "s_start", "s_end",
  "evalue", "bit_score", "cdd_id", "cdd_idb_id", "gene", "function", "aa_len"
)

colnames(df)
head(df)

#grep pfam
library(dplyr)

df_filtered <- df %>%
  filter(grepl("pfam", cdd_idb_id, ignore.case = TRUE))

View(df_filtered)
nrow(df_filtered)

#save
write.csv(
  df_filtered,
  "pfam_rows_clado.csv",
  row.names = FALSE
)

######################################################################################
#ORF A with any dominaof ORF B


# ---- PFAMs of interest ----
pfam_colors <- c(
  "pfam00078" = "#30123B",
  "pfam00665" = "#28BBEC",
  "pfam03732" = "#A2FC3C",
  "pfam17917" = "#FB8022",
  "pfam17921" = "#7A0403",
  "pfam12259" = "#8B008B"
)

pfam_keep <- c("pfam00078", "pfam00665", "pfam03732",
               "pfam17917", "pfam17921", "pfam12259")


# Filter only these PFAMs
df_filtered_keep <- df_filtered %>%
  filter(tolower(cdd_idb_id) %in% tolower(pfam_keep))

# Remove loci with only ONE PFAM domian of ORF A (pfam 03732)
loci_multi <- df_filtered_keep %>%
  group_by(query) %>%
  filter(n_distinct(tolower(cdd_idb_id)) > 1) %>%
  pull(query) %>% unique()


# Keep loci that contain pfam03732 + any other PFAM of ORF B
loci_with_03732 <- df_filtered_keep %>%
  filter(query %in% loci_multi,
         tolower(cdd_idb_id) == "pfam03732") %>%
  pull(query) %>% unique()

#Build plotting dataframe
df_plot_03732 <- df_filtered_keep %>%
  filter(query %in% loci_with_03732) %>%
  mutate(
    molecule = query,
    pfam     = cdd_idb_id,
    forward  = q_start <= q_end,
    xmin     = pmin(q_start, q_end),
    xmax     = pmax(q_start, q_end)
  )

# Plot function
plot_multi_genome <- function(df) {
  ggplot(df, aes(
    xmin = xmin,
    xmax = xmax,
    y    = molecule,
    fill = pfam,
    forward = forward
  )) +
    geom_gene_arrow(
      arrowhead_height = unit(3, "mm"),
      arrowhead_width  = unit(1, "mm")
    ) +
    scale_fill_manual(name = "PFAM ID", values = pfam_colors) +
    scale_y_discrete(labels = function(x) gsub("genomic\\.fna_", "", x)) +
    theme_genes() +
    theme(
      axis.text.y  = element_text(size = 8,  color = "black"),
      axis.text.x  = element_text(size = 10, color = "black"),
      axis.title.x = element_text(color = "black"),
      axis.title.y = element_text(color = "black"),
      plot.title   = element_text(hjust = 0.5, face = "bold", size = 14),
      legend.position = "right",
      panel.grid      = element_blank()
    ) +
    labs(
      title = "",
      x = "Genomic coordinates (bp)",
      y = "Genomic locus"
    )
}

#Plot all loci
plot_multi_genome(df_plot_03732)

#Plot ONLY the single locus prefix 
locus_prefix <- "GCF_002204515.2_AaegL5.0_genomic.fna_"
plot_multi_genome(
  df_plot_03732 %>%
    filter(grepl(paste0("^", locus_prefix), molecule))
)

# Count loci for a prefix
locus_prefix <- "GCF_002204515.2_AaegL5.0_genomic.fna_"

count_loci_prefix <- df_plot_03732 %>%
  filter(grepl(paste0("^", locus_prefix), molecule)) %>%
  pull(molecule) %>% unique() %>% length()

cat("Number of loci for prefix:", locus_prefix, "=", count_loci_prefix, "\n")

#######################################################################################
######################################################################################

#locus count for all loci (ORF A with ORF B any domian)
library(dplyr)
library(stringr)

#1. Keep the reusable function
count_loci_for_prefix <- function(df, prefix) {
  df %>%
    filter(grepl(paste0("^", prefix), molecule)) %>%
    pull(molecule) %>%
    unique() %>%
    length()
}


#Add a small loop to cat() counts for ALL prefixes
prefixes <- c(
  "GCA_015732765.1_VPISU_Cqui_1.0_pri_paternal_genomic.fna_",
  "GCA_016801865.2_TS_CPP_V2_genomic.fna_",
  "GCA_024139115.2_GZ_Asu_2_genomic.fna_",
  "GCA_024533555.2_Akor_1.1_genomic.fna_",
  "GCA_029784155.1_ASM2978415v1_genomic.fna_",
  "GCA_029784165.1_ASM2978416v1_genomic.fna_",
  "GCA_030247185.2_Malgen_1.1_genomic.fna_",
  "GCA_030247195.1_ASM3024719v1_genomic.fna_",
  "GCA_034211315.2_Ajap1v2_genomic.fna_",
  "GCA_035046485.1_AalbF5_genomic.fna_",
  "GCA_037179485.2_CSIRO-AGI_Acam_v1.1_genomic.fna_",
  "GCA_040801935.1_CSIRO_AGI_Anoto_v1_genomic.fna_",
  "GCA_044231785.1_Aedes_sierrensis_1_genomic.fna_",
  "GCA_943734655.2_idSabCyanKW18_F2_genomic.fna_",
  "GCA_964187845.1_idCulLati1.1_genomic.fna_",
  "GCA_964213205.1_idCulMode1.1_genomic.fna_",
  "GCA_964243045.1_idCulPerx1.1_genomic.fna_",
  "GCA_964340515.1_idCulThei1.1_genomic.fna_",
  "GCF_002204515.2_AaegL5.0_genomic.fna_"
)
for (p in prefixes) {
  count <- count_loci_for_prefix(df_plot_03732, p)
  cat("Number of loci for prefix:", p, "=", count, "\n")
}
