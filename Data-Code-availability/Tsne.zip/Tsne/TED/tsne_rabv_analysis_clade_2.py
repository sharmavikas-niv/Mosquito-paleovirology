#!/usr/bin/env python3

import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from Bio import SeqIO
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.cluster import DBSCAN


############################################################
# Clean protein sequence
############################################################

def clean_sequence(seq):

    valid_aas = set("ACDEFGHIKLMNPQRSTVWY")

    return "".join(
        aa for aa in str(seq).upper()
        if aa in valid_aas
    )


############################################################
# Main pipeline
############################################################

def run_pipeline(merged_fasta, eve_fasta, metadata_file):

    print("\nLoading metadata...")

    try:
        meta_df = pd.read_csv(
            metadata_file,
            sep="\t",
            dtype=str
        )

        if meta_df.shape[1] == 1:
            meta_df = pd.read_csv(
                metadata_file,
                dtype=str
            )

    except Exception:
        meta_df = pd.read_csv(
            metadata_file,
            dtype=str
        )

    ########################################################
    # Reference mapping
    ########################################################

    if (
        "sequence.sequenceID" in meta_df.columns and
        "alignment.displayName" in meta_df.columns
    ):

        clade_map = dict(
            zip(
                meta_df["sequence.sequenceID"],
                meta_df["alignment.displayName"]
            )
        )

    else:
        clade_map = {}

    ########################################################
    # Read EVE FASTA
    ########################################################

    print("Building EVE species mapping...")

    meta_df["alignment.displayName"] = (
        meta_df["alignment.displayName"]
        .astype(str)
        .str.replace("\n", "", regex=False)
        .str.strip()
    )

    eve_ids = dict(
        zip(
            meta_df["sequence.sequenceID"],
            meta_df["alignment.displayName"]
        )
    )

    print(
        f"Loaded {len(eve_ids)} EVE mappings"
    )

    ########################################################
    # Process merged FASTA
    ########################################################

    records = []
    labels = []
    seq_names = []

    print("Processing sequences...")

    for record in SeqIO.parse(
        merged_fasta,
        "fasta"
    ):

        seq = clean_sequence(record.seq)

        if len(seq) < 90:
            continue

        records.append(seq)

        seq_names.append(record.id)

        ####################################################
        # EVE sequence
        ####################################################

        if record.id in eve_ids:

            labels.append(
                eve_ids[record.id]
            )

        ####################################################
        # Reference sequence
        ####################################################

        else:

            seq_id = (
                record.id
                .split(".")[0]
                .split("|")[0]
            )

            clade = clade_map.get(
                seq_id,
                "Ref"
            )

            if pd.isna(clade) or clade == "-":
                clade = "Ref"

            labels.append("Ref")

    print(
        f"Sequences retained: {len(records)}"
    )

    ########################################################
    # 3-mer encoding
    ########################################################

    print("Generating 3-mer matrix...")

    vectorizer = CountVectorizer(
        analyzer="char",
        ngram_range=(3, 3)
    )

    X = vectorizer.fit_transform(records)

    scaler = StandardScaler()

    X_scaled = scaler.fit_transform(
        X.toarray()
    )

    ########################################################
    # PCA
    ########################################################

    n_comp = min(
        50,
        X_scaled.shape[0] - 1,
        X_scaled.shape[1]
    )

    print(
        f"Running PCA ({n_comp} PCs)"
    )

    pca = PCA(
        n_components=n_comp,
        random_state=42
    )

    X_pca = pca.fit_transform(
        X_scaled
    )

    ########################################################
    # t-SNE
    ########################################################

    perplexity = min(
        30,
        max(5, (len(records)-1)//3)
    )

    print(
        f"Running t-SNE (perplexity={perplexity})"
    )

    tsne = TSNE(
        n_components=2,
        perplexity=perplexity,
        learning_rate="auto",
        init="pca",
        random_state=42
    )

    X_tsne = tsne.fit_transform(
        X_pca
    )

    ########################################################
    # Dataframe
    ########################################################

    df = pd.DataFrame({

        "Sequence": seq_names,

        "TSNE1": X_tsne[:, 0],

        "TSNE2": X_tsne[:, 1],

        "Label": labels

    })

    ########################################################
    # Save coordinates
    ########################################################

    df.to_csv(
        "tsne_coordinates.tsv",
        sep="\t",
        index=False
    )

    ########################################################
    # Cluster counts
    ########################################################

    counts = (
        df["Label"]
        .value_counts()
        .reset_index()
    )

    counts.columns = [
        "Group",
        "Count"
    ]

    counts.to_csv(
        "cluster_counts.tsv",
        sep="\t",
        index=False
    )

    print("\nGroup counts:")

    print(counts)

    ########################################################
    # DBSCAN clusters
    ########################################################

    print(
        "\nRunning DBSCAN clustering..."
    )

    db = DBSCAN(
        eps=3,
        min_samples=3
    )

    df["Cluster"] = db.fit_predict(
        df[["TSNE1", "TSNE2"]]
    )

    df.to_csv(
        "tsne_clusters.tsv",
        sep="\t",
        index=False
    )

    print(
        "\nCluster summary:"
    )

    print(
        df["Cluster"]
        .value_counts()
        .sort_index()
    )

    ########################################################
    # Split EVE and Ref
    ########################################################

    eve_df = df[
        df["Label"] != "Ref"
    ]

    ref_df = df[
        df["Label"] == "Ref"
    ]

    eve_species = sorted(
        eve_df["Label"].unique()
    )

    print(
        "\nDetected EVE species:"
    )

    for sp in eve_species:
        print(sp)

    species_counts = (
        eve_df["Label"]
        .value_counts()
        .reset_index()
    )

    species_counts.columns = [
        "Species",
        "Count"
    ]

    species_counts.to_csv(
        "EVE_species_counts.tsv",
        sep="\t",
        index=False
    )

    print("\nEVE species counts:")
    print(species_counts)

    ########################################################
    # Colors
    ########################################################

    color_map = {

        "Wyeomyia_smithii_EVE": "#e41a1c",
        "Uranotaenia_lowii_EVE": "#377eb8",
        "Topomyia_yanbarensis_EVE": "#4daf4a",
        "Malaya_genurostris_EVE": "#984ea3",
        "Aedes_notoscriptus_EVE": "#ff7f00",
        "Ochlerotatus_sierrensis_EVE": "#ffff33",
        "Aedes_koreicus_EVE": "#a65628",
        "Aedes_japonicus_EVE": "#f781bf",
        "Aedes_aegypti_EVE": "#999999",
        "Culex_modestus_EVE": "#66c2a5",
        "Culex_quinquefasciatus_EVE": "#fc8d62",
        "Armigeres_subalbatus_EVE": "#8da0cb",
        "Aedes_albopictus_EVE": "#e78ac3",
        "Ochlerotatus_camptorhynchus_EVE": "#a6d854",
        "Culex_theileri_EVE": "#ffd92f",
        "Culex_laticinctus_EVE": "#e5c494",
        "Culex_perexiguus_EVE": "#b3b3b3",
        "Sabethes_cyaneus_EVE": "#1b9e77",
        "Culex_pipiens_EVE": "#d95f02"
    }

    ########################################################
    # Plot
    ########################################################

    plt.figure(
        figsize=(14, 10)
    )

    ########################################################
    # Reference proteins
    ########################################################

    plt.scatter(

        ref_df["TSNE1"],

        ref_df["TSNE2"],

        marker="o",

        color="red",

        s=18,

        alpha=0.65,

        edgecolors="none",

        zorder=1,

        label="Reference"

    )

    ########################################################
    # EVE stars
    ########################################################

    for species in eve_species:

        subset = eve_df[
            eve_df["Label"] == species
        ]

        plt.scatter(

            subset["TSNE1"],

            subset["TSNE2"],

            marker="*",

            s=90,

            alpha=0.90,

            color=color_map.get(species, "#ff0000"),

            edgecolor="black",

            linewidth=0.4,

            label=species.replace(
                "_EVE",
                ""
            ),

            zorder=100

        )

    ########################################################
    # Formatting
    ########################################################

    plt.title(
        "t-SNE Distribution of TED-like EVEs and Reference Proteins",
        fontsize=16
    )

    plt.xlabel(
        "t-SNE Dimension 1"
    )

    plt.ylabel(
        "t-SNE Dimension 2"
    )

    plt.grid(
        linestyle=":",
        alpha=0.3
    )

    plt.legend(
        bbox_to_anchor=(1.02, 1),
        loc="upper left",
        fontsize=10,
        frameon=False
    )

    plt.tight_layout()

    plt.savefig(
        "tsne_TED_EVE_species.png",
        dpi=600,
        bbox_inches="tight"
    )

    print(
        "\nSaved:"
    )

    print(
        "  tsne_TED_EVE_species.png"
    )

    print(
        "  tsne_coordinates.tsv"
    )

    print(
        "  cluster_counts.tsv"
    )

    print(
        "  tsne_clusters.tsv"
    )


############################################################
# Run
############################################################

if __name__ == "__main__":

    if len(sys.argv) != 4:

        print(
            "\nUsage:\n"
            "python3 tsne_TED_EVE_species.py "
            "<combined.fasta> "
            "<eve.fasta> "
            "<metadata.tsv>\n"
        )

        sys.exit(1)

    run_pipeline(

        sys.argv[1],

        sys.argv[2],

        sys.argv[3]

    )
