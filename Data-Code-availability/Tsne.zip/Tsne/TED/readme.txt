#conda environment
conda activate tsne

#Align sequence 
mafft --auto clusters_60_cdhit_centroids-head-sorted.faa > clusters_60_cdhit_centroids-head-sorted.aln

#make a seprate file with on EVE (puppy_isolate.fasta)


#run command 
./tsne_rabv_analysis_clade_2.py clusters_60_cdhit_centroids-head-sorted.aln EVE.fasta head.csv
