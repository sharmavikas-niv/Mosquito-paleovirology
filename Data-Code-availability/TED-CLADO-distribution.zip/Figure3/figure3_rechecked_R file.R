setwd("/home/ubuntu/NIV-projects/Mosquito-paleovirology/github/Neha/Figure4")
library(readr)

#Read file

df <- read.delim("merged_all_columns_nonoverlapping.tsv", stringsAsFactors = FALSE)

# First filter TED
TED_filtered <- df[grepl("Trichoplusia ni TED virus", df$Species, ignore.case = TRUE), ]

# Further filter for Protein.Products containing "ORF B"
TED_ORFB <- TED_filtered[grepl("ORF B", TED_filtered$Protein.Products, ignore.case = TRUE), ]

nrow(TED_ORFB)
View(TED_ORFB)
colnames(TED_ORFB)

# Count TED ORF B occurrences per organism
library(dplyr)
TED_ORFB_counts <- TED_ORFB %>%
  count(Organism.Name, name = "EVE_Count") %>%
  arrange(desc(EVE_Count))

# View the result
TED_ORFB_counts


#Addition of genome size
df <- read.csv("mosquito-genomes-06-03-2025.csv", header = TRUE)


names(df)


# STEP 2: Select relevant genome size info
genome_info <- df %>%
  select(Organism.Name, GenomeSize = Assembly.Stats.Total.Sequence.Length) %>%
  distinct()

# STEP 3: Merge EVE count with genome size
TED_merged_data <- left_join(TED_ORFB_counts, genome_info, by = "Organism.Name")

View(TED_merged_data)

# STEP 4: Calculate EVEs per megabase
merged_data <- TED_merged_data %>%
  mutate(EVE_per_Mb = EVE_Count / (GenomeSize / 1e6))

View(merged_data)

#Step 4: Save to file
write.csv(merged_data, "TED_ORFB_count_per_MB.csv", row.names = FALSE)

#############################################################################
# normalized plot TED EVE density
library(ggplot2)


P3 <- ggplot(merged_data,
             aes(x = reorder(Organism.Name, -EVE_per_Mb),
                 y = EVE_per_Mb)) +
  
  geom_bar(stat = "identity", fill = "#f6c85f", color = "black") +
  
  #  Inside bar (formula)
  geom_text(aes(
    y = EVE_per_Mb / 2,
    label = paste0(EVE_Count, "/", round(GenomeSize/1e6, 1))
  ),
  angle = 90,
  color = "black", size = 3.6) +
  
  #  Top of bar (density value)
  geom_text(aes(label = sprintf("%.2f", EVE_per_Mb)),
            vjust = -0.6,
            angle = 45,
            hjust = 0,
            size = 3.5) +
  
  expand_limits(y = max(merged_data$EVE_per_Mb) * 1.1) +
  
  theme_minimal() +
  
  labs(
    x = "Mosquito Genomes",
    y = "EVEs count per MB"
  ) +
  scale_y_continuous(expand = c(0, 0)) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(
      angle = 60, 
      hjust = 1, 
      color = "black",      # only black (no bold)
      face = "plain", 
      size = 10
    ),
    axis.text.y = element_text(
      color = "black",      # black color
      face = "bold",        # make bold
      size = 10
    ),
    axis.title = element_text(size = 12, face = "bold"),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    plot.margin = margin(10, 10, 10, 10)
  )

print(P3)

######################################################################################
#Cladosporium

#Read file

df <- read.delim("merged_all_columns_nonoverlapping.tsv", stringsAsFactors = FALSE)
names(df)


#filter Clado
clado_filtered <- df[grepl("Cladosporium fulvum T-1 virus", df$Species, ignore.case = TRUE), ]

# Further filter for Protein.Products containing "RT"
clado_RT <- clado_filtered[grepl("Reverse Transcriptase", clado_filtered$Protein.Products, ignore.case = TRUE), ]

nrow(clado_filtered)
nrow(clado_RT)


# Count clado RT occurrences per organism
library(dplyr)
clado_RT_counts <- clado_RT %>%
  count(Organism.Name, name = "EVE_Count") %>%
  arrange(desc(EVE_Count))

head(clado_RT_counts)


#Addition of genome size
df <- read.csv("mosquito-genomes-06-03-2025.csv", header = TRUE)

names(df)

# STEP 2: Select relevant genome size info
genome_info <- df %>%
  select(Organism.Name, GenomeSize = Assembly.Stats.Total.Sequence.Length) %>%
  distinct()

# STEP 3: Merge EVE count with genome size
clado_merged_data <- left_join(clado_RT_counts, genome_info, by = "Organism.Name")

View(clado_merged_data)

# STEP 4: Calculate EVEs per megabase
merged_data <- clado_merged_data %>%
  mutate(EVE_per_Mb = EVE_Count / (GenomeSize / 1e6))

View(merged_data)


#Step 4: Save to file
write.csv(merged_data, "clado_RT_count_per_MB.csv", row.names = FALSE)

##########################################################################
# normalized plot Clado EVE density
library(ggplot2)


P4 <- ggplot(merged_data,
             aes(x = reorder(Organism.Name, -EVE_per_Mb),
                 y = EVE_per_Mb)) +
  
  geom_bar(stat = "identity", fill = "#f4a3b4", color = "black") +
  
  #  Inside bar (formula)
  geom_text(aes(
    y = EVE_per_Mb / 2,
    label = paste0(EVE_Count, "/", round(GenomeSize/1e6, 1))
  ),
  angle = 90,
  color = "black", size = 3.6) +
  
  #  Top of bar (density value)
  geom_text(aes(label = sprintf("%.2f", EVE_per_Mb)),
            vjust = -0.6,
            angle = 45,
            hjust = 0,
            size = 3.5) +
  
  expand_limits(y = max(merged_data$EVE_per_Mb) * 1.1) +
  
  theme_minimal() +
  
  labs(
    x = "Mosquito Genomes",
    y = "EVEs count per MB"
  ) +
  scale_y_continuous(expand = c(0, 0)) +
  theme_minimal() +
  theme(
    axis.text.x = element_text(
      angle = 60, 
      hjust = 1, 
      color = "black",      # only black (no bold)
      face = "plain", 
      size = 10
    ),
    axis.text.y = element_text(
      color = "black",      # black color
      face = "bold",        # make bold
      size = 10
    ),
    axis.title = element_text(size = 12, face = "bold"),
    plot.title = element_text(size = 14, face = "bold", hjust = 0.5),
    panel.grid = element_blank(),
    axis.line = element_line(color = "black"),
    plot.margin = margin(10, 15, 10, 10)
  )
print(P4)

##########################################################################
#collage graphs with lebelling 
library(patchwork)


# Side-by-side collage

combined_plot <- (P3 | P4) +
  plot_annotation(tag_levels = "A")

combined_plot <- combined_plot &
  theme(plot.margin = margin(15, 10, 10, 10))

combined_plot

ggsave("Figure.3.pdf", width = 16, height = 8,dpi=600)
