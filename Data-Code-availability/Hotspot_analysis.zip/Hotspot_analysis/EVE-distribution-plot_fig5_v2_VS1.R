library(seqinr)
library(Biostrings)
library(ape)
library(ggtree)
library(ggplot2)
library(tibble)
library(dplyr)
library(svglite)
library(phytools)
library(tidyverse)
#BiocManager::install("Biostrings")
#BiocManager::install("ggtree")
#refernce (https://bioinformaticshome.com/bioinformatics_tutorials/R/phylogeny_estimation.html, http://yulab-smu.top/treedata-book/chapter13.html)
#PATH 
setwd("/home/ubuntu/NIV-projects/Mosquito-paleovirology/github/Distribution-hotspot/")
ht <- read.delim("Chromosome.csv", sep = "\t", header = TRUE)
df <- read.delim("mosquito-genomes-06-03-2025.csv", sep = "\t", header = TRUE)
eve <- read.delim("merged_all_columns_nonoverlapping.tsv", sep = "\t", header = TRUE)


#FILTER MAP FROM CHROMSOME "ht" file 
eve %>%
  dplyr::filter(seqname %in% ht$Seq) -> chrom
# seqnames=eve$seqname
# eve %>% filter(seqname %in% ht$Seq)-> chrom
droplevels(chrom)->chrom
#eve[seqnames(eve) %in% ht$Seq] -> chrom
# Add chromosome number from original df
for(l in 1:nrow(chrom)) {
  idx <- which(ht[,"Seq"] == as.character(chrom[l,"seqname"]))[1]
  chrom[l,"Chromosome"] <- ht[idx,"Chromosome"]
}

# Add chromosome number from original df
for(l in 1:nrow(chrom)) {
  idx <- which(ht[,"Seq"] == as.character(chrom[l,"seqname"]))[1]
  chrom[l,"Chromosome_Size"] <- ht[idx,"Size"]
}

#extract top 20 virus
#extract ted virus
chrom[grep("Trichoplusia ni TED virus", chrom$Species),]->ted
droplevels(ted)->ted

###
#ONLY ORFB 
ted[grep("ORF B", ted$Protein.Products),]->ted
droplevels(ted)->ted
#
library(dplyr)
###each ORF position (start) you can compute which bin (1–10) it falls into, based on the chromosome
ted_bins <- ted %>%
  mutate(
    start = as.numeric(start),
    Chromosome_Size = as.numeric(Chromosome_Size),
    bin = ceiling((start / Chromosome_Size) * 10)
  )

#count bin
orf_dist <- ted_bins %>%
  group_by(Organism.Name, Chromosome, bin) %>%
  summarise(count = n(), .groups = "drop")
# Add chromosome number from original df
for(l in 1:nrow(orf_dist)) {
  idx <- which(ted_bins[,"Organism.Name"] == as.character(orf_dist[l,"Organism.Name"]))[1]
  orf_dist[l,"Chromosome_Size"] <- ted_bins[idx,"Chromosome_Size"]
}
#mapping for proportion
#normalise vlaues
orf_dist$count/orf_dist$Chromosome_Size->orf_dist$prop

##################### Use the code for Fig 5 From here ####################
orf_dist$count/orf_dist$Chromosome_Size->orf_dist$prop
#########################################################
orf_dist1 <- orf_dist %>%
  group_by(Organism.Name,Chromosome) %>%
  mutate(prop_scaled = prop / max(prop, na.rm = TRUE))

######################Normalized distribution of ORF B across genomes################################
ggplot(orf_dist1, aes(x = bin, y = prop_scaled*100, color = Chromosome, group = Chromosome)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  facet_wrap(~ Organism.Name, scales = "fixed") +
  labs(
    x = "Genome bin (1-10)",
    y = "Scaled Proportion of ORF B (1–100)",
  ) +
  theme_minimal()
ggsave("Figure.5a.pdf", width = 12, height = 8,dpi=600)
###########################################
# Extract Cladosporium fulvum T-1 virus
clad <- chrom[grep("Cladosporium fulvum T-1 virus", chrom$Species), ]
clad <- droplevels(clad)

###
#ONLY Reverse Transcriptase 
clad[grep("Reverse Transcriptase", clad$Protein.Products),]->clad
droplevels(clad)->clad

# Bin assignment
clad_bins <- clad %>%
  mutate(
    start = as.numeric(start),
    Chromosome_Size = as.numeric(Chromosome_Size),
    bin = ceiling((start / Chromosome_Size) * 10)
  )

# Count per bin
orf_dist2 <- clad_bins %>%
  group_by(Organism.Name, Chromosome, bin, Chromosome_Size) %>%
  summarise(count = n(), .groups = "drop") %>%
  mutate(prop = (count / Chromosome_Size)*100)


### used the Min-Max normalization to make these values in 1-100####
orf_dist2$scaled <- 1 + (orf_dist2$prop - min(orf_dist2$prop)) *
  (100 - 1) /
  (max(orf_dist2$prop) - min(orf_dist2$prop))


# Plot normalized proportions
ggplot(orf_dist2, aes(x = bin, y = scaled, color = Chromosome, group = Chromosome)) +
  geom_line(linewidth = 1) +
  geom_point(size = 2) +
  facet_wrap(~ Organism.Name, scales = "free_y") +
  labs(
    x = "Genome bin (1-10)",
    y = "Scaled Proportion of Reverse Transcriptase (1–100)",
  ) +
  theme_minimal()
ggsave("Figure.5b.pdf", width = 12, height = 8,dpi=600)
